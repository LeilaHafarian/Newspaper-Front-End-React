import { useState } from "react";
import { Link } from "react-router-dom";
import "./sidebar.css";
const SideBar = ({ children }) => {
  const [selectedMenu, setSelectedMenu] = useState("Artiklar");
  const menus = [
    { value: "Artiklar", link: "/" },
    { value: "Journalister", link: "/journalist" },
    { value: "Bilder", link: "/builder" },
  ];
  return (
    <div className="side-bar">
      <div className="app-bar"></div>
      <div className="container">
        <div className="drawer">
          <ul>
            {menus.map((menu) => {
              return (
                <li
                  onClick={() => {
                    setSelectedMenu(menu.value);
                  }}
                  key={menu.value}
                  className={selectedMenu === menu.value ? "selected-menu" : ""}
                >
                  <Link to={menu.link}>{menu.value}</Link>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="content">{children}</div>
      </div>
    </div>
  );
};
export default SideBar;
