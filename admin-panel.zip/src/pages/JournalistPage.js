const JournalistPage = () => {
  return <h1>JournalistPage</h1>;
};
export default JournalistPage;
