import { useEffect, useState } from "react";
import "./article.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen, faTrash } from "@fortawesome/free-solid-svg-icons";
import { getAllArticles } from "../apis/API";
const articles = [
  {
    text: "article1",
  },
  {
    text: "article2",
  },
  {
    text: "article3",
  },
  {
    text: "article4",
  },
];
const ArticlePage = () => {
  const [artcileList, setArticleList] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const result = await getAllArticles();
    console.log({ result });
  };
  return (
    <>
      <div className="article-header">
        <h1>Artiker</h1>
        <button>Skapa</button>
      </div>
      <hr />
      <ul className="articles">
        {articles.map((article, index) => {
          return (
            <li key={index}>
              <label>{article.text}</label>
              <div className="actions">
                <button>
                  <FontAwesomeIcon icon={faPen} />
                </button>
                <button>
                  {" "}
                  <FontAwesomeIcon icon={faTrash} />
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    </>
  );
};
export default ArticlePage;
