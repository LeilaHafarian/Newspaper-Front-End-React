import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import SideBar from "./components/SideBar";
import ArticlePage from "./pages/ArticlePage";
import JournalistPage from "./pages/JournalistPage";

function App() {
  return (
    <BrowserRouter>
      <SideBar>
        <Routes>
          <Route path={"/"} exact element={<ArticlePage />} />
          <Route path={"/journalist"} exact element={<JournalistPage />} />
        </Routes>
      </SideBar>
    </BrowserRouter>
  );
}

export default App;
