import axios from "axios";
let baseURL = "https://localhost:44368/api/";
axios.defaults.baseURL = baseURL;
const responseBody = (response) => response;
const errorBody = (error) => {
  return error.response;
};
const requests = {
  get: (url) => axios.get(url).then(responseBody).catch(errorBody),
  post: (url, body) =>
    axios.post(url, body).then(responseBody).catch(errorBody),
  put: (url, body) => axios.put(url, body).then(responseBody).catch(errorBody),
  delete: (url) => axios.delete(url).then(responseBody).catch(errorBody),
};
const Articles = {
  getArticles: () => requests.get(`Articles`),
};

export const getAllArticles = async () => {
  try {
    const response = await Articles.getArticles();
    return response;
  } catch (error) {
    return error;
  }
};
